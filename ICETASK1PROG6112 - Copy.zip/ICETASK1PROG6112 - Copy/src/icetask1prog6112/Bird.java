/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask1prog6112;

import java.util.Scanner;

/**
 *
 * @author Dell 5420
 */
public class Bird extends Animals {
        
  private  String species;
private String Colour;
/*
    public String getSpecies() {
        return Species;
    }

    public void setSpecies(String Species) {
        this.Species = Species;
    }

    public String getColour() {
        return Colour;
    }

    public void setColour(String Colour) {
        this.Colour = Colour;
    }
  */  
   
  
  public Bird() {
        this.species = species;
        this.Colour = Colour;
    }
      public void brdInput(){
        Scanner kb = new Scanner(System.in);
        System.out.println("ENTER SPECIES OF BIRD");
        species = kb.nextLine();
        
          System.out.println("ENTER COLOUR OF BIRD"
                  + "\n GRAY"
                  + "\n WHITE"
                  + "\n BLACK");
          Colour = kb.nextLine();
    }
      public void brdOutput(){
          System.out.println("SPECIES IS:" + Species);
          System.out.println("FEATHER COLOUR IS:" + Colour);
      }
 

    
}
