/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask1prog6112;

import java.util.Scanner;

/**
 *
 * @author Dell 5420
 */
public class Animals {
   
    
     
    
    
 private int IDtag;
  
  String Species;

  public Animals()
  {
      
      this.IDtag = IDtag;
      this.Species = Species;
  }
        public void AniInput()
        {
          Scanner kb = new Scanner(System.in);
            System.out.println("Enter animals ID tag");
            IDtag = kb.nextInt();
                  
           
        }  
         
        public void AniOutput()
        {
            Scanner kb = new Scanner(System.in);
            System.out.println("Enter the species of the animal, bird or reptile");
            this.Species= kb.nextLine();
           System.out.println("ID tag is:"+ IDtag);
            System.out.println("Species of animal is:"+ Species);
            
            
        }
    
}
