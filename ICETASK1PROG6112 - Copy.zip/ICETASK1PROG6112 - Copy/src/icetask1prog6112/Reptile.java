/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask1prog6112;

import java.util.Scanner;

/**
 *
 * @author Dell 5420
 */
public class Reptile extends Animals{
    
   private String speciez;
   private  double bloodtemp;
    
    public Reptile() {
        this.speciez= speciez;
        this.bloodtemp = bloodtemp;
    }
    
     public void reptInput(){
        Scanner kb = new Scanner(System.in);
        System.out.println("ENTER SPECIES OF BIRD");
        speciez = kb.nextLine();
        
          System.out.println("ENTER COLOUR OF BIRD"
                  + "\n GRAY"
                  + "\n WHITE"
                  + "\n BLACK");
          bloodtemp = kb.nextInt();
    }
      public void reptOutput(){
          System.out.println("SPECIES IS:" + speciez);
          System.out.println("blood temprature is:" +bloodtemp+ " degrees celcius");
      }
    
}
